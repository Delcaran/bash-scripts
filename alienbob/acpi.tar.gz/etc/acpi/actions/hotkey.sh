#!/bin/sh

# /etc/acpi/actions/hotkey.sh
# Take actions when IBM hotkeys are pressed

# Written by Robby Workman <rw@rlworkman.net> for public domain

# First let's verify that $2 and $3 are correct
# This probably isn't needed at all
[ "$2" = "HKEY" ] || exit 1
[ "$3" = "00000080" ] || exit 1

# Now the real work :)
case "$4" in
  #00001001) logger "Action not defined for F1." ;;
  #00001002) logger "Action not defined for F2." ;;
  #00001003) logger "Action not defined for F3." ;;
  00001004) /etc/acpi/actions/s2ram.sh ;;
  #00001005) logger "Action not defined for F5." ;;
  #00001006) logger "Action not defined for F6." ;;
  00001007) /etc/acpi/actions/switch_video.sh toggle ;;
  #00001008) logger "Action not defined for F8." ;;
  #00001009) logger "Action not defined for F9." ;;
  #0000100a) logger "Action not defined for F10." ;;
  #0000100b) logger "Action not defined for F11." ;;
  0000100c) /etc/acpi/actions/s2disk.sh ;;
esac


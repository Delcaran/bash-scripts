#!/bin/sh

# Suspend to disk when power button is pressed

# First, let's make sure we're not shutting down or rebooting
if [ ! -e /etc/powerdown ]; then
  sync ; sync # Just in case...
  echo -n disk > /sys/power/state
fi


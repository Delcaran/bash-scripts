#!/bin/sh

# Suspend to ram when the lid is closed

# First, let's make sure we're not shutting down or rebooting
if [ ! -e /etc/powerdown ]; then
  sync ; sync # Just in case...
  echo -n mem > /sys/power/state
fi


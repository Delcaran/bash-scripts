<?php
if (!isset($used_id)) {
	$result = @mysql_query("SELECT pid FROM pastebin ORDER BY pid DESC LIMIT 0,1");
	$used_id = @mysql_result($result, 0, 0);
}
if ($used_id == "") $used_id = 0;
?>

<div id="credits">So far, <?php echo $used_id; ?> files have been shared with <a href="http://sox.homeip.net/uploadbin/">Alien's Uploadbin</a><br/>|  <a href="credits.php">Credits</a> |</div>

</body>
</html>

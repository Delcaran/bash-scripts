<?php
include("init.php");

//Setup the application variables
if ($_POST) $action=$_POST['action'];
if (!isset($action)) $action = '';

//Make sure the files that are over 7 days old, are purged
$timeNow = time()-(86400*$expiredays);
$result = @mysql_query("SELECT * FROM $tableName WHERE unix_timestamp(posted) < '$timeNow' AND expired = '0'");
while ($row = @mysql_fetch_array($result, MYSQL_NUM)) {
	//print_r($row);
	$newresult = @mysql_query("UPDATE $tableName SET expired = 1, posted = '$row[2]' WHERE pid=$row[0]");
	}
?>

<?php
include("header.php");
?>

<div id="titlebar">UploadBin: Browse for a file on your computer, suggest a password and click on "Upload File".
	<p>Anyone who wants to download your file, will need to know the password in order to be able to access the file (password may be empty if you don't care who can access it).
	<br/>Your information will be recorded along with the file to monitor abuse, and the file will be available for up to <?php echo $expiredays ?> days.</p>
</div>

<div id="content">
<?php

switch($action) {

	//This is where is upload is processed
case 'upload':
		$OrigFileName = $_FILES['uploadfile']['name'];
		$UploadFileName = tempnam($UploadDir, "up_");
		if (move_uploaded_file($_FILES['uploadfile']['tmp_name'], $UploadFileName)) {
			$poster = $_SERVER['REMOTE_ADDR'];
			$code = $_POST['epass'];
			$file_location = $UploadFileName;
			$filename = $OrigFileName;
			$md5 = md5_file($file_location);
			$result = @mysql_query("insert into $tableName(poster, code, file_location, filename, md5) values('$poster', '$code', '$file_location', '$filename', '$md5')");
			$used_id = @mysql_insert_id($dbconnect);
			if ($result != 1) die('Sorry, could not post file');
			}
		$downloadURI = $downloadURI.$used_id;
		?><h1>File Uploaded Successfully</h1><?php
		echo "This is  the URI for your upload: <a href=\"$downloadURI\">$downloadURI</a>";
		echo "<br/>The password to be used is: <strong>$code</strong>";
		echo "<br/>The MD5 sum is: <p1>$md5</p1>";
		echo "<br/><br/>Your information has been recorded with the download and will be used in case of abuse.
		This download will be available for up to $expiredays days from the date of upload with the provided password.<br/><br/>";
?>
	<h1>Upload New File</h1>
	<form ENCTYPE="multipart/form-data" name="post" action="index.php" method="post" id="post">
		<input type="hidden" name="action" value="upload" />
		File to be uploaded&nbsp;&nbsp;<input type="file" name="uploadfile" id="uploadfile" size="35" />
		<br/><br/>Password&nbsp;&nbsp;<input type="password" name="epass" size="30" tabindex="1" id="epass" />
		<br/><br/><input name="upload" type="submit" id="upload" tabindex="2" value="Upload File" />
	</form>
<?php
		break;

default:
?>
	<h1>Upload New File</h1>
	<form ENCTYPE="multipart/form-data" name="post" action="index.php" method="post" id="post">
		<input type="hidden" name="action" value="upload" />
		File to be uploaded&nbsp;&nbsp;<input type="file" name="uploadfile" id="uploadfile" size="35" />
		<br/><br/>Password&nbsp;&nbsp;<input type="password" name="epass" size="30" tabindex="1" id="epass" />
		<br/><br/><center><input name="upload" type="submit" id="upload" tabindex="2" value="Upload File" /></center>
	</form>
	<?php
	break;
}
?>

</div>

<?php
include("footer.php");
?>

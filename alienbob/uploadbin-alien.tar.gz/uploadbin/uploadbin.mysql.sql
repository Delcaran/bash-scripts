-- If you are installing 'uploadbin' for the first time, you can simply
-- direct this file to mysql as STDIN:
--
-- $ mysql --user=root --password=<MySQL-root-password> < uploadbin.mysql.sql
--
-- If you are upgrading from a previous version, you will need to comment
-- out the the user creation steps below, as well as the schemas for any
-- tables that already exist.


USE mysql;

REPLACE INTO user (host, user, password)
    VALUES (
        'localhost',
        'uploadbin',
-- IMPORTANT: Change this password!
        PASSWORD('uploadbin')
);

REPLACE INTO db (host, db, user, select_priv, insert_priv, update_priv,
                 delete_priv, create_priv, drop_priv, index_priv)
    VALUES (
        'localhost',
        'uploadbin',
        'uploadbin',
        'Y', 'Y', 'Y', 'Y',
        'Y', 'Y', 'Y'
);

-- Make sure that priviliges are reloaded.
FLUSH PRIVILEGES;

-- Create the database and table, after that we're ready to rock'n'roll...
CREATE DATABASE uploadbin;

USE uploadbin;

CREATE TABLE `pastebin`
(
    `pid` int(11) NOT NULL auto_increment,
    `poster` varchar(24) default NULL,
    `posted` timestamp(14) NOT NULL,
    `code` text,
    `expired` int(1) default '0',
    `file_location` text NOT NULL,
    `filename` text NOT NULL,
    `md5` varchar(33) NOT NULL,
    PRIMARY KEY  (`pid`),
    FULLTEXT KEY `file_location` (`file_location`)
) TYPE=MyISAM AUTO_INCREMENT=01;


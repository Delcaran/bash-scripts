<?php
// Setup the MySQL connection parameters.
// Use the file uploadbin.mysql.sql to create the MySQL database.
// See the README for instructions (take special care to choose a new password).
$dbHost = "localhost";
$dbUser = "uploadbin";
$dbPass = "uploadbin";

// If you want a different name for the database and/or table, be sure to
// change it in "uploadbin.mysql.sql" too, before importing it into MySQL.
$dbName = "uploadbin";
$tableName = "pastebin";

// Replace this with the actual URI for your uploadbin. You can omit the
// 'http://hostname' part here, in which case the uploadbin will determine
// the appropriate hostname using information supplied by the browser.
// An example:
// $baseURI = "http://my.server.com/uploadbin/";
$baseURI = "/uploadbin";

// Fancy URL scheme (like 'http://your.webhost.com/uploadbin/13')
// The use of fancy URLs is determined by a RewriteRule in .htaccess
// if your web server allows that.
// Value: true or false
$fancyURL = true;

// The $UploadDir variable determines where uploadbin stores the uploaded files.
// This defaults to the 'upload' subdirectory in uploadbin's installation
// directory in Apache's DocumentRoot.
// This directory must be writeable by the web server process! The upload files
// will be stored with randomized filenames, but uploadbin will remember their
// original names.
// Example:
// $UploadDir = "/tmp/uploads";

// Number of days that an uploaded file remains available for download
// Note that expired files will become unavailable for download through the
// uploadbin app, but the files themselves remain on your server! Setup a
// cron job to remove them if you want.
$expiredays = 7;

?>

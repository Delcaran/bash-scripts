<?php
include("init.php");
error_reporting(E_ALL);

//Setup the application variables
if ($_POST) $action=$_POST['action'];
if (!isset($action)) $action = '';

if (!isset($_GET['pid']) && !isset($_POST['action'])) die('Please do not access this page without a download ID');

switch($action) {

	//This is where is download is processed
case 'download':
		$submitpid = $_POST['submitpid'];
		$result = @mysql_query("SELECT code,file_location,filename FROM pastebin WHERE pid=$submitpid AND expired = '0'");
		$used_code = @mysql_result($result, 0, 0);
		if ($used_code == $_POST['passEntered']) {
			$file = mysql_result($result, 0, 1);
			$fnam = mysql_result($result, 0, 2);
			header("Pragma: public");
			header("Expires: 0");
			header("Cache-Control: must-revalidate, post-check=0, pre-check=0");

			header("Content-Type: application/force-download");
			header("Content-Disposition: attachment; filename=".$fnam);

			header("Content-Description: File Transfer");
			@readfile($file);
		}
		else die('Wrong Password or file expired, please click your back button and try again');
		exit();
		break;

default:
		exit();
}
?>

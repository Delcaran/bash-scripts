<?php 
include("init.php"); 
?>

<?php 
include("header.php"); 
?>

<?php
	$pid = $_GET['pid'];
	$result = @mysql_query("SELECT file_location,md5 FROM pastebin WHERE pid=$pid AND expired = '0'");
	if (mysql_num_rows($result) != 1) {
		$file = "NONEXISTANT";
	}
	else {
		$file = mysql_result($result, 0, 0);
		$md5 = mysql_result($result, 0, 1);
		$md5file = md5_file($file);
	}
?>
<body>
<br/>
<div id="content">
	<h1>Please type in the password for the file download</h1>
	<form name="password" action="getfile.php" method="post" id="post">
		<input type="hidden" name="action" value="download" />
		<input type="hidden" name="submitpid" value="<?php echo $_GET['pid']; ?>" />
		Password for requested file&nbsp;&nbsp;<input type="password" name="passEntered" id="passEntered" size="35" />
		<br/><center><input name="submit" type="submit" id="submit" tabindex="2" value="Submit Password" /></center>
<?php 
echo "<br />File integrity check:";
if ($file == "NONEXISTANT") {
echo "<br />Error: <p1>No such file</p1>";
}
elseif ($md5 == $md5file) {
echo "<br />Recorded MD5 hash matches with the file.";
echo "<br />MD5 hash:<p1>$md5</p1>";
}
else {
echo "<br />Looks like the file got corrupted; the MD5 hashes don't match.";
echo "<br /><p2>$md5</p2> : MD5 hash recorded with the upload.";
echo "<br /><p2>$md5file</p2> : Current MD5 hash of the file.";
}

?>
	</form>

</div>

<?php
include("footer.php");
?>

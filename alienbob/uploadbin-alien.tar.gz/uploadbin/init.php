<?php
include_once("config.php");

// Maximum file size in BYTES, no idea why it does not work for me.
ini_set('upload_max_filesize','1');
// Time in seconds when an upload timeout will occur
set_time_limit(9000);

// Path to upload files to
if (!isset($UploadDir)) {
	$UploadDir = dirname(__FILE__).'/upload/';
} else {
	if ($UploadDir[strlen($UploadDir) - 1] != '/')
		$UploadDir = $UploadDir."/";
}

// The base URI
if ($baseURI[strlen($baseURI) - 1] != '/') $baseURI = $baseURI."/";
if (strpos($baseURI,"http") === false || strpos($baseURI,"http") != 0) {
	$baseURI = "http://".$_SERVER["HTTP_HOST"].$baseURI;
}

// Fancy URL scheme is like 'http://your.webhost.com/uploadbin/13'
// The use of fancy URLs is determined by a RewriteRule in .htaccess
// if your web server allows that.
if ($fancyURL)
	$downloadURI = $baseURI;
else
	$downloadURI = $baseURI."download.php?pid=";

// Connect and test mysql, error out if required
$dbconnect = @mysql_connect($dbHost,$dbUser,$dbPass);
if ($dbconnect == '') die('Could not connect to database!');
$dbresult = @mysql_select_db($dbName,$dbconnect);
if ($dbresult != 1) die('Database could not be selected, please check databasename in configuration file!');

?>

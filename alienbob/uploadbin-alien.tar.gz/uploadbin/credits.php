<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<title>UploadBin for all your File Upload Needs</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<style type="text/css" media="screen">
		@import url( layout.css );
	</style>
</head>

<body>

<div id="credits"> <a href="http://www.slackware.com/~alien">Alien's</a> adaptation of <a href="http://weblogtoolscollection.com">Mark Ghosh</a> UploadBin | Inspired by <a href="http://paste.uni.cc">PHP Pastebin</a> | MD5 hack by <a href="http://www.myworld.se">Henrik</a><br/>| <a href="/uploadbin-20051215.tar.gz">Download</a> |</div>

</body>
</html>
